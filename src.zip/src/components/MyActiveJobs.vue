<template>
    <h1>Active Jobs</h1>
    <div v-for = "job in jobs" :key="job.id" class="jobs">
        <router-link :to="{ name: 'Job', params: { id: job.id } }">
            <div class="row border p-1">
                <div class="col-md-6">
                <p>{{ job.jobNumber }} - {{ job.street }}, {{ job.city }}</p>
                </div>
                <div class="col-md-6">
                    <div class="progress mt-3" role="progressbar" aria-label="Info example" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100">
                        <div class="progress-bar" v-bind:style="{width: job.pcntComplete + '%'}">{{ job.pcntComplete }}% Complete</div>
                    </div>
                </div>
            </div>
        </router-link>
          </div>
  </template>
  
  <script>
  import axios from 'axios';

  export default {
   
       props:['myName'],
    data() {
          return {
          jobs: {}
          }
      },
       mounted(){
        this.getOptionsFromTable('customerdata')
        },
        methods: {
            async getOptionsFromTable(table) {
  return axios
    .get(`http://localhost:8000/databaseAPI.php?table=${table}`)
    .then((response) => {
      if (Array.isArray(response.data)) { // Check if response.data is an array
        this.jobs = response.data.filter((job) =>
          (job.pM === this.myName ||
            job.engineer === this.myName ||
            job.technician === this.myName) &&
          job.Status === "Active"
        );
      } else {
        console.log("Invalid response data format");
      }
    })
    .catch((error) => {
      console.log(error);
    });
},
}
  
  }
  </script> 
   <style>
 
    
 .jobs p{
     background:#f4f4f4;
     padding:5px;
     border: 1px solid rgb(0,68,141);
     border-radius: 10px;
     margin: 10px auto ;
     max-width: 600px;
     cursor: pointer;
     color:#444;
 }
 .jobs p:hover{
     background:#ddd;
 }
 .jobs a{
     text-decoration: none;
 }
 </style>