<template>
    <h1>All Jobs</h1>
    <div v-for = "job in jobs" :key="job.id" class="jobs">
        <router-link :to="{ name: 'Job', params: { id: job.id } }">
                <p>{{ job.jobNumber }} - {{ job.street }}, {{ job.city }}, Status - {{ job.Status }}</p>
        </router-link>
          </div>
  </template>
  
  <script>
  export default {
   
      props:['myName'],
    data() {
          return {
          jobs: {}
          }
          const name=createNode()
      },
       mounted(){
          fetch( 'http://localhost:3000/Jobs/')
          .then(res=> res.json())
          .then (data => {
              this.jobs = data.filter(job =>
              job.pM === this.myName ||
              job.engineer === this.myName ||
              job.technician ===this.myName
              );
              console.log(this.myName)
          })
          .catch(err => console.log(err.message))       
      }
  
  }
  </script>