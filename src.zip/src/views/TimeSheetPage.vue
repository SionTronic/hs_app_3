<template>
  <h1>Timesheet page</h1>
  <div class="container">
    <navButtons/>
  </div>
</template>

<script>
import navButtons from '@/components/navButtons.vue';
export default {
    components: {
      navButtons,
    }
}
</script>

<style>

</style>