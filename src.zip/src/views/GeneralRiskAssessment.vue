<template>
  <div class="container">
    <!-- <textarea v-model="riskAssessment"></textarea> -->
    <navButtons></navButtons>
    <h1>{{ $route.params.jobName }}</h1>

    <risk-assessment-modal 
      v-if="modal1Visible" 
      :modal1Visible="modal1Visible"  
      :assessments="assessmentItems" 
      @close="closeModal" 
      @save="handleSelectedItems"
      @new="openNewAssessmentModal">
    </risk-assessment-modal>

    <newRiskAssessmentModal
      v-if="modal2Visible"
      :modal2Visible="modal2Visible"
      @closeModal2="closeModal2" 
      @record="recordAssessment">
    </newRiskAssessmentModal>

    <risk-assessment-list 
      :items="assessmentItems">
    </risk-assessment-list>

    <button @click="openModal" class="button2">Add</button>
  </div>
</template>

<script>
import RiskAssessmentModal from '@/components/RiskAssessmentModal.vue'
import newRiskAssessmentModal from '@/components/newRiskAssessmentModal.vue'
import RiskAssessmentList from '@/components/RiskAssessmentList.vue'
import navButtons from '@/components/navButtons.vue';
import axios from 'axios'


export default {

props:['id'],

  // Rest of the component definition
components: {
    RiskAssessmentModal,
    newRiskAssessmentModal,
    RiskAssessmentList,
    navButtons
  },

  data() {
    return {
      job:'',
      riskAssessment:'',
      modal1Visible: false,
      modal2Visible: false,
      assessmentItems: [],
      assessmentIDs:[],
    }
  },
  mounted() {
      this.getJobRiskAssessments();
      this.getData();
      this.jobNumber = this.$route.params.jobNumber;
  },
  methods: {
      async getJobRiskAssessments(){
        const url = 'http://localhost:8000/databaseAPI.php';
        const params = new URLSearchParams({
            table: 'assessments_customerdata',
            customer_id: this.id,
          });
            try {
            const response = await fetch(`${url}?${params}`);
            const data = await response.json();
            this.assessmentIDs = data.map(item => item.assessment_id);
          } catch (error) {
            console.log(error.message);
          }
      },

      async getData() {
        const url = 'http://localhost:8000/databaseAPI.php';
        const params = new URLSearchParams({
            table: 'assessments'
          });
          try {
            const response = await fetch(`${url}?${params}`);
            const data = await response.json();
            
            const filteredItems = data.filter(assessment => this.assessmentIDs.includes(assessment.id));
            this.assessmentItems = filteredItems;
            
            console.log('assessmentItems', this.assessmentItems);
          } catch (error) {
            console.log(error.message);
          }
      },  
 
      recordAssessment(data){
        const assessmentData = {
            hazard: data.selectedHazard, 
            consequence: data.selectedInjury, 
            severity:data.severity, 
            probability: data.probability, 
            risk: data.risk, 
            peopleEffected: data.selectedPeopleEffected, 
            mitigation:data.selectedMitigation, 
            mitigatedSeverity:data.mitigatedSeverity, 
            residualRisk: data.residualRisk, 
            effectiveness: data.effectiveness
          };
          this.recordTableData('recordAssessment',assessmentData)

          // for (const [key, value] of Object.entries(assessmentData)) {

          //   switch (key) {
          //     case 'hazard':
          //       // Handle hazard logic
          //       const hazardData = {hazard:assessmentData.hazard, weighting: assessmentData.severity}
          //       this.recordTableData('hazards',hazardData)
          //       break;
          //     case 'consequence':
          //       // Handle consequence logic
          //       const injuryData = {injury_name:assessmentData.consequence, weighting: assessmentData.severity}
          //       this.recordTableData('injury',injuryData)
          //       break;
          //     case 'peopleEffected':
          //       // Handle severity logic
          //       const peopleData = {category:assessmentData.peopleEffected}
          //       this.recordTableData('people_effected',peopleData)
          //       break;
          //     // Add more cases for other keys as needed
          //     case 'mitigation':
          //       // Handle severity logic
          //       const mitigationData = {mitigation:assessmentData.mitigation, mitigated_severity:assessmentData.mitigatedSeverity}
          //       this.recordTableData('mitigation',mitigationData)
          //       break;
              // case 'hazard':
              //   // Record actual assessment
              //   const allData = {hazard:assessmentData.hazard, 
              //                   consequence: assessmentData.consequence,
              //                   severity:assessmentData.severity, 
              //                   probability: assessmentData.probability, 
              //                   risk: assessmentData.risk, 
              //                   peopleEffected: assessmentData.peopleEffected, 
              //                   mitigation:assessmentData.mitigation, 
              //                   mitigatedSeverity:assessmentData.mitigatedSeverity, 
              //                   residualRisk: assessmentData.residualRisk, 
              //                   effectiveness: assessmentData.effectiveness
              //                 }
              //   this.recordTableData('hazards',allData)
              //   break;
            //   default:
            //     // Handle default case
                
            // }

            // const injuryMitigation = {injury_name:assessmentData.consequence, 
            //                         mitigation:assessmentData.mitigation,
            //                         weighting: assessmentData.severity,
            //                         mitigated_severity:assessmentData.mitigatedSeverity}
            //                         this.recordTableData('injury_mitigation',injuryMitigation)
            // // this.closeModal2();
         // }

            // axios.post('http://localhost:8000/databaseAPI.php?table=assessments', assessmentData)
            // .then(response => {
            //     const responseData = response.data;
            //     console.log('Assessment data sent successfully:', responseData);
            //   })
            // .catch(error => {
            //   console.log(error.message);
            //   });
          },

      openModal() {
      this.modal1Visible = true
      console.log(this.modal1Visible)
      },
      
      closeModal(){
        console.log("close modal")
        this.modal1Visible=false
      },
      closeModal2(){
        console.log("close modal 2")
        this.modal2Visible = false
      },
        saveRiskAssessment() {
        // this.riskAssessments.push(data)
        console.log("save risk assessment")
        
      },
          handleSelectedItems(selectedItems) {
            this.assessmentItems.push(...selectedItems);
            console.log('Selected items:', selectedItems);
      },

      deleteRiskAssessment(id) {
      // Delete the risk assessment with the given ID from the list
      this.assessmentItems = this.assessmentItems.filter((record) => record.id !== id);
      },
      editRiskAssessment(id) {
        // Edit the risk assessment with the given ID
        // This logic is specific to your use case and depends on how you want to implement editing
        console.log(`Editing risk assessment with ID ${id}`);
      },
      openNewAssessmentModal(){
        this.modal2Visible = true
        console.log('modal2Visible', this.modal2Visible)
      },
      
      recordTableData(table,tableData){
        axios.post(`http://localhost:8000/databaseAPI.php?table=${table}`,tableData)
            .then(response => {
                const responseData = response.data;
                console.log('Assessment data sent successfully:', responseData);
              })
            .catch(error => {
              console.log(error.message);
              });
          },

  },
}
  </script>
  <style>

.button2{
    text-decoration: none;
    background:#fff;
    text-align:left;  
    padding:5px;
    border-radius: 4px;
    border: 1px solid rgb(0,68,141); 
    margin: 10px 10px 10px 10px;
    max-width: 600px;
    cursor: pointer;
    color:#444;
}

.button2:hover{
    background:rgba(0,68,141,0.5); 
    color:white;
}

</style>