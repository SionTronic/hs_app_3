<template>
  <div class="home">
  <h1> Welcome / Croeso  </h1> 
  
  </div>
</template>

<script>


export default {
  name: 'Home',

}
</script>
<style>
.home{
  text-align: center;
}
</style>