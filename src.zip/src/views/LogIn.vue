<template>
<h1>Login</h1>

<div @click="loginToTabsAsMartin"  class="button">
  <router-link to = "/MyTabs/Martin">
 Login as Martin
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Sion">
 Login as Sion
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Ifan">
 Login as Ifan
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Byron">
 Login as Byron
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Tom">
 Login as Tom
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Aled">
 Login as Aled
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Erin">
 Login as Erin
</router-link>
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Camila">
 Login as Camila
</router-link>
</div>
 
</template>

<script>
export default {
  
 
 

}
</script>

<style>



</style>