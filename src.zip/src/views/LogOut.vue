<template>
<h1>LogOut</h1>
  <!-- <router-view/> -->
</template>

<script>
export default {

}
</script>

<style>

</style>