<?php
function handleRecordAssessment($request_data, $con, $customer_id) {
    $hazard = $request_data['hazard'];
    $consequence = $request_data['consequence'];
    $severity = $request_data['severity'];
    $probability = $request_data['probability'];
    $risk = $request_data['risk'];
    $peopleEffected = $request_data['peopleEffected'];
    $mitigation = $request_data['mitigation'];
    $mitigatedSeverity = $request_data['mitigatedSeverity'];
    $residualRisk = $request_data['residualRisk'];
    $effectiveness = $request_data['effectiveness'];

    // Start a transaction
    $con->beginTransaction();

    try {
        // Insert into the 'assessments' table
        $assessmentStmt = $con->prepare("INSERT INTO assessments (hazard, consequence, severity, probability,
                                         risk, peopleEffected, mitigation, mitigatedSeverity, residualRisk, effectiveness)
                                         VALUES (:hazard, :consequence, :severity, :probability, :risk, 
                                         :peopleEffected, :mitigation, :mitigatedSeverity, :residualRisk,:effectiveness");
        $assessmentStmt->bindParam(':hazard', $hazard);
        $assessmentStmt->bindParam(':consequence', $consequence);
        $assessmentStmt->bindParam(':severity', $severity);
        $assessmentStmt->bindParam(':probability', $probability);
        $assessmentStmt->bindParam(':risk', $risk);
        $assessmentStmt->bindParam(':peopleEffected', $peopleEffected);
        $assessmentStmt->bindParam(':mitigation', $mitigation);
        $assessmentStmt->bindParam(':mitigatedSeverity', $mitigatedSeverity);
        $assessmentStmt->bindParam(':residualRisk', $residualRisk);
        $assessmentStmt->bindParam(':effectiveness', $effectiveness);
        $assessmentStmt->execute();
        $assessmentId = $con->lastInsertId(); // Get the last inserted ID

        // Insert into the 'injury' table
        if (checkIfItemExists($consequence,'injury_name','injury', $con)){
        $injuryStmt = $con->prepare( "UPDATE injury SET weighting_$severity =  weighting_$severity + 1 WHERE injury_name = :consequence");
            } else {
        // Insert statement
        $injuryStmt = $con->prepare("INSERT INTO injury (injury_name, weighting_$severity) VALUES (:consequence, 1)");
        }
        $injuryStmt->bindParam(':consequence', $consequence, );
        $injuryStmt->execute();
        $injuryId = $con->lastInsertId(); // Get the last inserted ID

        // Insert into the 'mitigation' table
        $mitigationStmt = $con->prepare("INSERT INTO mitigation (mitigation, mitigatedSeverity)
                                         VALUES (:mitigation, :mitigatedSeverity)");
        $mitigationStmt->bindParam(':mitigation', $mitigation);
        $mitigationStmt->bindParam(':mitigatedSeverity', $mitigatedSeverity);
        $mitigationStmt->execute();
        $mitigationId = $con->lastInsertId(); // Get the last inserted ID

        // Insert into the 'customer_hazard' table
        $customerHazardStmt = $con->prepare("INSERT INTO customer_hazard (customer_id, hazard_id)
                                             VALUES (:customer_id, :hazard_id)");
        $customerHazardStmt->bindParam(':customer_id', $customer_id);
        $customerHazardStmt->bindParam(':hazard_id', $hazard_id);
        $customerHazardStmt->execute();

        // Insert into the 'injury_mitigation' table
        $injuryMitigationStmt = $con->prepare("INSERT INTO injury_mitigation (injury_id, mitigation_id, mitigated_severity)
                                               VALUES (:injury_id, :mitigation_id, :mitigated_severity)");
        $injuryMitigationStmt->bindParam(':injury_id', $injuryId);
        $injuryMitigationStmt->bindParam(':mitigation_id', $mitigationId);
        $injuryMitigationStmt->bindParam(':mitigated_severity', $mitigatedSeverity);
        $injuryMitigationStmt->execute();

        // Commit the transaction
        $con->commit();

        echo "Assessment
   
    }
}
}