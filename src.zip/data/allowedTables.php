<?php

$allowedTables = array(
    'injury', 
    'customerData', 
    'jobs', 
    'activity', 
    'equipment', 
    'hazards',
    'people_effected',
    'mitigation',
    'assessments',
    'injury_mitigation',
    'customerdata',
    'hazard_customerdata',
    'assessments_customerdata',
    'recordAssessment');
?>