import axios from 'axios'

// axios.defaults.baseURL='http://cadarn.wales/data/';
axios.defaults.baseURL='http://localhost:8000/';