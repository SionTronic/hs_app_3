<template>
  <div class="home">
  <h1> Welcome / Croeso  </h1> 
  <p>All data in this application has been generated for the purposes of testing and is entirely fictional.</p>
  
  </div>
</template>

<script>


export default {
  name: 'Home',

}
</script>
<style>
.home{
  text-align: center;
}
</style>