<template>
<h1>Login</h1>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Ifan">
 Login as Ifan
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/Jobs2">
 Login as Caryl
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/Jobs2">
 Login as Catrin
</router-link> 
</div>
<div @click="loginToTabsAsMartin"  class="button">
  <router-link to = "/MyTabs/Bryn">
 Login as Bryn
</router-link> 
</div>
<div @click="loginToTabsAsMartin"  class="button">
  <router-link to = "/MyTabs/Bryan">
 Login as Bryan
</router-link> 
</div>
<div @click="loginToTabsAsMartin"  class="button">
  <router-link to = "/MyTabs/Ian">
 Login as Ian
</router-link> 
</div>

<div @click="loginToTabsAsMartin"  class="button">
  <router-link to = "/MyTabs/Dylan">
 Login as Dylan
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Aled">
 Login as Aled
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Byron">
 Login as Byron
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Camila">
 Login as Camila
</router-link>
</div>
<div @click="loginToTabsAsMartin"  class="button">
  <router-link to = "/MyTabs/Martin">
 Login as Martin
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Sion">
 Login as Sion
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Tom">
 Login as Tom
</router-link> 
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Erin">
 Login as Erin
</router-link>
</div>
<div @click="loginToTabsAsSion"  class="button">
  <router-link to = "/MyTabs/Mich">
 Login as Michael
</router-link>
</div>

 
</template>

<script>
export default {
  
 
 

}
</script>

<style>



</style>